A JobSearch Platform that can generate shortened links.

Hi! 

I built this demo UI to give you a sample of the link shortening generator. I used React for the component structure and design.


This is a frontend-only demo that shows how a job search platform would work:

1. Job Listings Dashboard - You're able to browse jobs from various companies.
2. Company Registration - Companies can register to post jobs on the platform.
3. Link Generation - After registering, companies get a unique shareable link.
4. Copy to Clipboard - This makes it easy to share.

There's no backend, database, or API integration. It all runs in the browser.

The Tech Stack:

- React 
- Tailwind CSS 
- Lucide React 
- JavaScript  

Features I Built

Clean, responsive dashboard with job cards  
Multi-step user flow (Dashboard → Registration → Success)  
Modal popup with success feedback  
Copy-to-clipboard functionality  
URL slug generation from company names  
 


This project runs on CodeSandbox, so you can:

1. View it live - Just click the preview link: https://wxqxsp.csb.app/
2. Download it - Export and run locally with `npm install` then `npm start`



If I were to build this as a full-stack application, I'd add:

- Backend API with Node.js/Express
- Database (PostgreSQL or MongoDB) to store companies and jobs
- User authentication and authorization
- Real link generation with unique IDs
- Analytics dashboard for tracking profile views
- Job application system
- Email notifications
- Search and filter functionality
- Company profile pages with actual content


My Contact:

Feel free to reach out if you have questions about the code at: marvellousbraimah71@gmail.com or call +234 810 292 1387



